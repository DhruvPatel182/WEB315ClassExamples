namespace AssignmentSample.Models
{
    public class Content
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public string Type { get; set; }
        public string Body { get; set; }
        public string Tag { get; set; }
        public string ImgUrl { get; set; }
    }

}